const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8765;
const SVG_PATH = path.join(__dirname, 'logo-wenzhou-leyi.svg');

const server = http.createServer((req, res) => {
  const svg = fs.readFileSync(SVG_PATH, 'utf8');
  res.writeHead(200, { 'Content-Type': 'image/svg+xml' });
  res.end(svg);
});

server.listen(PORT, () => {
  console.log(`SVG server running at http://localhost:${PORT}/`);
});
